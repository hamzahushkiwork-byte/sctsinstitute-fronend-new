import { useEffect, useState, useCallback } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { getCourseBySlug } from '../api/courses.api.js'
import { registerForCourse, getUserCourseRegistration } from '../api/courseRegistration.api.js'
import { useAuth } from '../contexts/AuthContext.jsx'
import { toAbsoluteMediaUrl } from '../utils/mediaUrl.js'
import PageHero from '../components/PageHero'
import PaymentComingSoonModal from '../components/modals/PaymentComingSoonModal'
import '../styles/course-details.css'

function CourseDetails() {
  const { slug } = useParams()
  const navigate = useNavigate()
  const { isAuthenticated, user } = useAuth()
  const [activePayment, setActivePayment] = useState('visit')
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false)
  const [course, setCourse] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [registering, setRegistering] = useState(false)
  const [registrationMessage, setRegistrationMessage] = useState('')
  const [registration, setRegistration] = useState(null)
  const [checkingRegistration, setCheckingRegistration] = useState(false)

  const checkRegistrationStatus = useCallback(async (courseId) => {
    if (!isAuthenticated || !courseId) {
      setRegistration(null)
      setCheckingRegistration(false)
      return
    }

    // Set a timeout to ensure checkingRegistration always resets
    const timeoutId = setTimeout(() => {
      setCheckingRegistration(false)
    }, 10000) // 10 second timeout

    try {
      setCheckingRegistration(true)
      const reg = await getUserCourseRegistration(courseId)
      clearTimeout(timeoutId)
      // Set registration (null means not registered, object means registered)
      setRegistration(reg || null)
    } catch (err) {
      clearTimeout(timeoutId)
      console.error('Failed to check registration status:', err)
      // On any error, assume not registered
      setRegistration(null)
    } finally {
      // Always set checking to false
      setCheckingRegistration(false)
    }
  }, [isAuthenticated])

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'smooth' })
  }, [slug])

  useEffect(() => {
    async function loadCourse() {
      if (!slug) {
        navigate('/courses')
        return
      }

      try {
        setLoading(true)
        setError(null)
        const data = await getCourseBySlug(slug)
        setCourse(data)

        // Check registration status if user is authenticated
        if (isAuthenticated && data?._id) {
          checkRegistrationStatus(data._id)
        }
      } catch (err) {
        console.error('Failed to load course:', err)
        setError(err.response?.status === 404 ? 'Course not found' : 'Failed to load course')
        if (err.response?.status === 404) {
          setTimeout(() => navigate('/courses'), 2000)
        }
      } finally {
        setLoading(false)
      }
    }

    loadCourse()
  }, [slug, navigate, isAuthenticated, checkRegistrationStatus])

  // Refresh registration status when user authentication changes
  useEffect(() => {
    if (!isAuthenticated) {
      setRegistration(null)
      setCheckingRegistration(false)
      return
    }

    if (course?._id && !checkingRegistration) {
      checkRegistrationStatus(course._id)
    }
  }, [isAuthenticated, course?._id, checkRegistrationStatus])

  const handlePaymentClick = (type) => {
    if (type === 'mastercard') {
      setIsPaymentModalOpen(true)
      return
    }
    setActivePayment(type)
  }

  const handleRegister = async () => {
    if (!isAuthenticated) {
      navigate('/login', { state: { from: `/courses/${slug}` } })
      return
    }

    if (!course?._id) {
      setRegistrationMessage('Course information is missing')
      return
    }

    setRegistering(true)
    setRegistrationMessage('')

    try {
      const newRegistration = await registerForCourse(course._id)
      // Ensure registration has status field and proper structure
      if (newRegistration) {
        if (!newRegistration.status) {
          newRegistration.status = 'pending'
        }
        setRegistration(newRegistration)
        setRegistrationMessage('Successfully registered for this course! Status: Pending')
      } else {
        // If registration failed but no error thrown, refresh status
        await checkRegistrationStatus(course._id)
        setRegistrationMessage('Registration completed. Checking status...')
      }
      // Clear message after 5 seconds
      setTimeout(() => setRegistrationMessage(''), 5000)
    } catch (err) {
      if (err.message.includes('already registered')) {
        // Refresh registration status
        await checkRegistrationStatus(course._id)
        setRegistrationMessage('You are already registered for this course')
        setTimeout(() => setRegistrationMessage(''), 5000)
      } else {
        setRegistrationMessage(err.message || 'Failed to register. Please try again.')
      }
    } finally {
      setRegistering(false)
    }
  }

  const getStatusDisplay = (status) => {
    switch (status) {
      case 'paid':
        return { text: 'Paid ✓', color: '#10b981', bgColor: '#d1fae5', textColor: '#065f46' }
      case 'pending':
        return { text: 'Pending', color: '#f59e0b', bgColor: '#fef3c7', textColor: '#92400e' }
      case 'rejected':
        return { text: 'Rejected', color: '#ef4444', bgColor: '#fee2e2', textColor: '#991b1b' }
      default:
        return { text: 'Unknown', color: '#6b7280', bgColor: '#f3f4f6', textColor: '#374151' }
    }
  }

  if (loading) {
    return (
      <section className="course-detail-page" dir="rtl">
        <div className="course-detail-container">
          <div style={{ textAlign: 'center', paddingTop: '60px' }}>
            <p>Loading...</p>
          </div>
        </div>
      </section>
    )
  }

  if (error || !course) {
    return (
      <section className="course-detail-page" dir="rtl">
        <div className="course-detail-container">
          <h1 className="course-detail-title">Course not found</h1>
          <p className="course-detail-lead">
            {error || 'Course details not found. Please return to the course catalog.'}
          </p>
          <Link className="course-back-button" to="/courses">
            Back to Course Catalog
          </Link>
        </div>
      </section>
    )
  }

  const imageUrl = course.imageUrl ? toAbsoluteMediaUrl(course.imageUrl) : ''

  return (
    <section className="course-detail-page" dir="rtl">
      <PageHero
        title={course.title}
        subtitle={course.shortDescription || undefined}
        backgroundImage={imageUrl}
        breadcrumbs={[
          { label: 'Courses', path: '/courses' },
          { label: course.title, path: '#' }
        ]}
      />
      <div className="course-detail-container">
        {/* Registration Status Section */}
        <div style={{ marginBottom: '24px' }}>
          {course.isAvailable === false ? (
            <div style={{ marginBottom: '16px' }}>
              <div
                style={{
                  display: 'inline-block',
                  padding: '12px 24px',
                  backgroundColor: '#fef3c7',
                  color: '#92400e',
                  borderRadius: '8px',
                  fontWeight: '700',
                  marginBottom: '12px',
                  border: '1px solid #f59e0b'
                }}
              >
                هذه الدورة ستكون متاحة قريباً (Coming Soon)
              </div>
              <button
                disabled
                style={{
                  display: 'block',
                  padding: '12px 24px',
                  fontSize: '16px',
                  fontWeight: '600',
                  backgroundColor: '#f3f4f6',
                  color: '#4b5563',
                  border: '1px solid #d1d5db',
                  borderRadius: '8px',
                  cursor: 'not-allowed',
                }}
              >
                قريباً (Coming Soon)
              </button>
              <p style={{ marginTop: '8px', color: '#6b7280', fontSize: '14px' }}>
                هذه الدورة ستتوفر قريباً للتسجيل. انتظروا التحديثات!
              </p>
            </div>
          ) : isAuthenticated ? (
            <>
              {checkingRegistration ? (
                <div style={{ padding: '12px', color: '#666', fontSize: '14px' }}>
                  Checking registration status...
                </div>
              ) : registration ? (
                <div style={{ marginBottom: '16px' }}>
                  <div
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '12px',
                      padding: '12px 20px',
                      borderRadius: '8px',
                      backgroundColor: getStatusDisplay(registration.status || 'pending').bgColor,
                      color: getStatusDisplay(registration.status || 'pending').textColor,
                      fontSize: '15px',
                      fontWeight: '600',
                      marginBottom: '12px',
                    }}
                  >
                    <span>Registration Status:</span>
                    <span
                      style={{
                        padding: '4px 12px',
                        borderRadius: '6px',
                        backgroundColor: getStatusDisplay(registration.status || 'pending').color,
                        color: '#ffffff',
                        fontSize: '14px',
                      }}
                    >
                      {getStatusDisplay(registration.status || 'pending').text}
                    </span>
                  </div>
                  {registration.notes && (
                    <div
                      style={{
                        marginTop: '8px',
                        padding: '10px',
                        borderRadius: '6px',
                        backgroundColor: '#f3f4f6',
                        color: '#374151',
                        fontSize: '13px',
                      }}
                    >
                      <strong>Note:</strong> {registration.notes}
                    </div>
                  )}
                </div>
              ) : (
                <button
                  onClick={handleRegister}
                  disabled={registering}
                  style={{
                    padding: '12px 24px',
                    fontSize: '16px',
                    fontWeight: '600',
                    backgroundColor: '#667eea',
                    color: '#ffffff',
                    border: 'none',
                    borderRadius: '8px',
                    cursor: registering ? 'not-allowed' : 'pointer',
                    opacity: registering ? 0.7 : 1,
                    transition: 'all 0.2s ease',
                  }}
                >
                  {registering ? 'Registering...' : 'Register for Course'}
                </button>
              )}
              {registrationMessage && (
                <div
                  style={{
                    marginTop: '12px',
                    padding: '12px',
                    borderRadius: '8px',
                    backgroundColor: registration ? '#d1fae5' : '#fee2e2',
                    color: registration ? '#065f46' : '#991b1b',
                    fontSize: '14px',
                  }}
                >
                  {registrationMessage}
                </div>
              )}
            </>
          ) : (
            <button
              onClick={() => navigate('/login', { state: { from: `/courses/${slug}` } })}
              style={{
                padding: '12px 24px',
                fontSize: '16px',
                fontWeight: '600',
                backgroundColor: '#667eea',
                color: '#ffffff',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
            >
              Login to Register
            </button>
          )}
        </div>

        {course.description && (
          <div className="course-detail-content">
            <div
              className="course-detail-paragraph"
              style={{ whiteSpace: 'pre-line' }}
            >
              {course.description}
            </div>
          </div>
        )}

        <div className="course-payments">
          <h2 className="course-detail-heading">طرق الدفع</h2>
          <div className="course-payment-grid">
            <button
              type="button"
              className="payment-card"
              onClick={() => handlePaymentClick('mastercard')}
              aria-label="الدفع باستخدام MasterCard"
            >
              <span className="payment-icon" aria-hidden="true">
                MC
              </span>
              <span className="payment-title">MasterCard</span>
              <span className="payment-subtitle">انتقل إلى صفحة الدفع</span>
            </button>
            <button
              type="button"
              className={`payment-card ${activePayment === 'visit' ? 'is-active' : ''
                }`}
              onClick={() => handlePaymentClick('visit')}
              aria-label="الدفع من خلال زيارة المركز"
              aria-pressed={activePayment === 'visit'}
            >
              <span className="payment-icon" aria-hidden="true">
                VC
              </span>
              <span className="payment-title">الدفع من خلال زيارة المركز</span>
              <span className="payment-subtitle">تفاصيل العنوان والتواصل</span>
            </button>
            <button
              type="button"
              className={`payment-card ${activePayment === 'bank' ? 'is-active' : ''
                }`}
              onClick={() => handlePaymentClick('bank')}
              aria-label="حوالة بنكية"
              aria-pressed={activePayment === 'bank'}
            >
              <span className="payment-icon" aria-hidden="true">
                BT
              </span>
              <span className="payment-title">حوالة بنكية</span>
              <span className="payment-subtitle">بيانات الحساب البنكي</span>
            </button>
          </div>

          {activePayment === 'visit' && (
            <div className="payment-details" role="status">
              <h3>زيارة المركز</h3>
              <p>
                العنوان: شارع التدريب، مبنى المهارات الطبية، الدور الثالث.
              </p>
              <p>الهاتف: 0000 000 050</p>
              <p>ساعات العمل: من 9 صباحاً إلى 6 مساءً.</p>
            </div>
          )}

          {activePayment === 'bank' && (
            <div className="payment-details" role="status">
              <h3>الحوالة البنكية</h3>
              <p>اسم البنك: بنك التدريب الوطني</p>
              <p>رقم الحساب: 1234567890</p>
              <p>IBAN: SA00 0000 0000 0000 0000 0000</p>
            </div>
          )}
        </div>
      </div>

      <PaymentComingSoonModal
        open={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        courseName={course.slug}
      />
    </section>
  )
}

export default CourseDetails
