import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getCertificationBySlug } from '../api/certification.api.js';
import { toAbsoluteMediaUrl } from '../utils/mediaUrl.js';
import PageHero from '../components/PageHero';
import '../styles/certification-detail.css';

function CertificationDetails() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [certification, setCertification] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadCertification() {
      if (!slug) {
        navigate('/certification');
        return;
      }

      try {
        setLoading(true);
        setError(null);
        const data = await getCertificationBySlug(slug);
        setCertification(data);
      } catch (err) {
        console.error('Failed to load certification:', err);
        setError(err.response?.status === 404 ? 'Certification not found' : 'Failed to load certification');
        if (err.response?.status === 404) {
          setTimeout(() => navigate('/certification'), 2000);
        }
      } finally {
        setLoading(false);
      }
    }

    loadCertification();
  }, [slug, navigate]);

  useEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'smooth',
    });
  }, [slug]);

  if (loading) {
    return (
      <section className="certification-details">
        <div className="certification-details-content" style={{ textAlign: 'center', paddingTop: '60px' }}>
          <p>Loading...</p>
        </div>
      </section>
    );
  }

  if (error || !certification) {
    return (
      <section className="certification-details">
        <div className="certification-details-content" style={{ textAlign: 'center', paddingTop: '60px' }}>
          <p>{error || 'Certification not found'}</p>
          <button onClick={() => navigate('/certification')} style={{ marginTop: '20px', padding: '10px 20px' }}>
            Back to Certifications
          </button>
        </div>
      </section>
    );
  }

  const heroImageUrl = certification.heroImageUrl ? toAbsoluteMediaUrl(certification.heroImageUrl) : '';
  const innerImageUrl = certification.innerImageUrl ? toAbsoluteMediaUrl(certification.innerImageUrl) : '';

  return (
    <section className="certification-details">
      <PageHero
        title={certification.title}
        subtitle={certification.heroSubtitle || undefined}
        backgroundImage={heroImageUrl}
        breadcrumbs={[
          { label: 'Certification', path: '/certification' },
          { label: certification.title, path: '#' }
        ]}
      />

      {/* Content Section */}
      <div className="certification-details-content">
        <div className="certification-details-content-inner">
          {innerImageUrl && (
            <div className="certification-details-image-container">
              <img
                src={innerImageUrl}
                alt={certification.title}
                className="certification-details-image"
                onError={(e) => {
                  e.target.style.display = 'none';
                }}
              />
            </div>
          )}
          <div className="certification-details-text">
            {certification.description ? (
              <div 
                className="certification-details-description"
                style={{ whiteSpace: 'pre-line' }}
              >
                {certification.description}
              </div>
            ) : (
              <p>No description available.</p>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

export default CertificationDetails;
