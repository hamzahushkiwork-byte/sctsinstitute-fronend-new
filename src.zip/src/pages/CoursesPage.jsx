import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import PageHero from '../components/PageHero'
import { getCoursesList } from '../api/courses.api.js'
import { toAbsoluteMediaUrl } from '../utils/mediaUrl.js'
import '../styles/courses.css'

function CoursesPage() {
  const [courses, setCourses] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'smooth',
    })
  }, [])

  useEffect(() => {
    async function loadCourses() {
      try {
        setLoading(true)
        const data = await getCoursesList()
        setCourses(data || [])
      } catch (err) {
        console.error('Failed to load courses:', err)
        setCourses([])
      } finally {
        setLoading(false)
      }
    }

    loadCourses()
  }, [])

  const staticCourses = [
    { id: 1, name: 'Advanced Trauma Life Support (ATLS)', duration: '2 Days' },
    { id: 2, name: 'Basic Life Support (BLS)', duration: '1 Day' },
    { id: 3, name: 'Advanced Cardiac Life Support (ACLS)', duration: '2 Days' },
    { id: 4, name: 'Pediatric Advanced Life Support (PALS)', duration: '2 Days' },
    { id: 5, name: 'Neonatal Resuscitation Program (NRP)', duration: '1 Day' },
    { id: 6, name: 'First Aid & Heart Saver', duration: '1 Day' },
    { id: 7, name: 'Infection Control', duration: '1 Day' },
    { id: 8, name: 'Disaster Management', duration: '2 Days' },
    { id: 9, name: 'Continuous Medical Education (CME)', duration: '1 Day' },
  ]

  return (
    <div>
      <PageHero
        title="Course Catalog"
        subtitle="Browse our comprehensive list of courses"
        backgroundImage="https://images.unsplash.com/photo-1551601651-2a8555f1a136?w=1920&q=80"
        breadcrumbs={[
          { label: 'Courses', path: '/courses' }
        ]}
      />
      <section className="courses-section">
        <div className="courses-container">
          <h2 className="courses-title">Courses List</h2>

          <div className="courses-table-wrapper">
            <table className="courses-table">
              <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>Course</th>
                  <th>Duration</th>
                </tr>
              </thead>
              <tbody>
                {staticCourses.map((course) => (
                  <tr key={course.id}>
                    <td>{course.id}</td>
                    <td>{course.name}</td>
                    <td>{course.duration}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {loading ? (
            <div className="available-courses" dir="rtl" style={{ marginTop: '72px', textAlign: 'center', padding: '40px' }}>
              <p>Loading courses...</p>
            </div>
          ) : courses.length === 0 ? (
            <div className="available-courses" dir="rtl" style={{ marginTop: '72px', textAlign: 'center', padding: '40px' }}>
              <p>No courses available at this time.</p>
            </div>
          ) : (
            <div className="available-courses" dir="rtl">
              <div className="available-courses-header">
                <h3 className="available-courses-title">الدورات المتاحة</h3>
                <p className="available-courses-subtitle">
                  اختر الدورة المناسبة لك واستعرض التفاصيل الكاملة.
                </p>
              </div>
              <div className="course-cards-grid">
                {courses.map((course) => {
                  const imageUrl = course.imageUrl ? toAbsoluteMediaUrl(course.imageUrl) : ''

                  return (
                    <Link
                      key={course._id || course.id || course.slug}
                      to={`/courses/${course.slug}`}
                      className="course-card"
                      aria-label={`عرض تفاصيل ${course.title}`}
                    >
                      {imageUrl ? (
                        <img
                          src={imageUrl}
                          alt={course.title}
                          className="course-card-image"
                          loading="lazy"
                          onError={(e) => {
                            e.target.style.display = 'none'
                            const placeholder = e.target.parentElement.querySelector('.course-card-placeholder')
                            if (placeholder) {
                              placeholder.style.display = 'flex'
                            }
                          }}
                        />
                      ) : null}
                      <div
                        className="course-card-placeholder"
                        style={{
                          display: imageUrl ? 'none' : 'flex',
                          height: '352px',
                          background: '#e2e8f0',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: '#718096',
                          fontSize: '14px',
                          fontWeight: '500'
                        }}
                      >
                        <span>No Image</span>
                      </div>
                      <div className="course-card-body">
                        <h4 className="course-card-title">{course.title}</h4>
                        {course.isAvailable === false ? (
                          <div className="course-card-availability-badge" style={{ backgroundColor: '#fef3c7', color: '#92400e' }}>
                            Coming Soon
                          </div>
                        ) : (
                          <div className="course-card-availability-badge" style={{ backgroundColor: '#d1fae5', color: '#065f46' }}>
                            Available Now
                          </div>
                        )}
                      </div>
                      <div className="course-card-overlay">
                        {course.cardBody && (
                          <p className="course-card-desc">{course.cardBody}</p>
                        )}
                        <span className="course-card-cta">
                          {course.isAvailable === false ? 'Coming Soon' : 'Available Now →'}
                        </span>
                      </div>
                    </Link>
                  )
                })}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}

export default CoursesPage
