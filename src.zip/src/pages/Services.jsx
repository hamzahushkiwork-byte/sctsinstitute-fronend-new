import { useEffect } from 'react'
import PageHero from '../components/PageHero'
import ServicesSection from '../components/ServicesSection'

function Services() {
  useEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'smooth',
    })
  }, [])

  return (
    <div>
      <PageHero
        title="Our Services"
        subtitle="Comprehensive medical training and professional development programs"
        backgroundImage="https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=1920&q=80"
        breadcrumbs={[
          { label: 'Services', path: '/services' }
        ]}
      />
      <ServicesSection />
    </div>
  )
}

export default Services

