import HeroSlider from '../components/HeroSlider'
import WelcomeSection from '../components/WelcomeSection'
import TrainingProgramsSection from '../components/TrainingProgramsSection'
import HolisticApproachSection from '../components/HolisticApproachSection'
import ServicesSection from '../components/ServicesSection'

function Home() {
  return (
    <div>
      <HeroSlider />
      <WelcomeSection />
      <TrainingProgramsSection />
      <HolisticApproachSection />
      <ServicesSection />
    </div>
  )
}

export default Home
