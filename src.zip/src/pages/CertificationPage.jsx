import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { getCertificationList } from '../api/certification.api.js';
import PageHero from '../components/PageHero.jsx';
import { toAbsoluteMediaUrl } from '../utils/mediaUrl.js';
import '../styles/certification.css';

function CertificationPage() {
  const [certifications, setCertifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'smooth',
    });
  }, []);

  useEffect(() => {
    async function loadCertifications() {
      try {
        setLoading(true);
        const data = await getCertificationList();
        setCertifications(data || []);
      } catch (err) {
        console.error('Failed to load certifications:', err);
        setCertifications([]);
      } finally {
        setLoading(false);
      }
    }

    loadCertifications();
  }, []);

  return (
    <div>
      <PageHero
        title="Certification"
        subtitle="Comprehensive training and certification programs"
        backgroundImage="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=1920&q=80"
        breadcrumbs={[
          { label: 'Certification', path: '/certification' }
        ]}
      />
      
      <section className="certification-intro">
        <div className="certification-intro-inner">
          <h2>We provide medical training solutions</h2>
          <p>
            Our comprehensive certification programs are designed to enhance your medical expertise 
            and advance your career. Each program is carefully crafted to meet industry standards 
            and provide you with the knowledge and skills needed to excel in your field.
          </p>
        </div>
      </section>

      {loading ? (
        <section className="certification-list">
          <div className="certification-list-inner">
            <div style={{ padding: '60px 20px', textAlign: 'center' }}>
              <p>Loading certifications...</p>
            </div>
          </div>
        </section>
      ) : certifications.length === 0 ? (
        <section className="certification-list">
          <div className="certification-list-inner">
            <div style={{ padding: '60px 20px', textAlign: 'center' }}>
              <p>No certifications available at this time.</p>
            </div>
          </div>
        </section>
      ) : (
        <section className="certification-list">
          <div className="certification-list-inner">
            {certifications.map((cert) => {
              const imageUrl = cert.cardImageUrl ? toAbsoluteMediaUrl(cert.cardImageUrl) : '';
              
              return (
                <Link
                  key={cert._id || cert.id || cert.slug}
                  to={`/certification/${cert.slug}`}
                  className="certification-card"
                >
                  <div className="certification-card-image-container">
                    {imageUrl ? (
                      <img
                        src={imageUrl}
                        alt={cert.title}
                        className="certification-card-image"
                        onError={(e) => {
                          e.target.style.display = 'none';
                          e.target.nextSibling.style.display = 'block';
                        }}
                      />
                    ) : null}
                    <div className="certification-card-placeholder" style={{ display: imageUrl ? 'none' : 'block' }}>
                      <span>No Image</span>
                    </div>
                  </div>
                  <div className="certification-card-content">
                    <h3 className="certification-card-title">{cert.title}</h3>
                    <p className="certification-card-description">{cert.shortDescription || ''}</p>
                    <div className="certification-card-link">Learn more →</div>
                  </div>
                </Link>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}

export default CertificationPage;
